%Chapter 4��Multi-Robot Formation Switching Based on Voronoi Tessellations

close all
clear all
clc

n=8;
crs = [0,0;0,10;10,10;10,0];
showPlot = 1;
showPlot2 = 1;
showPlot3 = 1;
r_sen = 2; 

Kprop = 0.3; 
Ki = 0;
Kd = 0;

Umax = 0.3;
Umin = -0.3;
max_speed = 1;

start=1;
xin=1;



Px=[0.800922775268557;2.204487664358964;3.454351915631986;4.550781032017319;5.548388508387978;6.641229139055539;7.891007941109820;9.298161315918026];
Py=[4.099969482421896;4.099969482421892;4.099969482421889;4.099969482421889;4.099969482421889;4.099969482421889;4.099969482421892;4.099969482421896];
fg=0;


opx = Px;
opy = Py;
PPx = Px;
PPy = Py;
oox=Px;
oox=Py;
line_x=Px';
line_y=Py';
xrange = max(crs(:,1));
yrange = max(crs(:,2));
thresh = 0.01; 
dist = zeros(n,1);
ddist = 10*ones(n,1);
lenth = zeros(n,1);
counter = 0;
cycle=1;


X1 = max(max(crs))/100;
r_sen = r_sen/X1;
load('line_to_ring_icgnc6.mat');
ZZZ=ZD;


rgb={[255,0,0],[0 255 255],...
     [255,0,255],[255,255,0],[255,97,0],...
     [0,0,255],[211,0,63],...
     [0,255,0]};

C = {}; 
 for i=1:n
     C{i}=rgb{i}*0.00392;
 end
 
if showPlot
    figure
    verCellHandle = zeros(n,1);
    cellColors = ones(n,3);
    for i = 1:numel(Px) 
        verCellHandle(i) = patch(Px(i),Py(i),cellColors(i,:)); % use color i  -- no robot assigned yet
        hold on
    end
    pathHandle = zeros(n,1);
    
    for i = 1:numel(Px) 
       pathHandle(i)  = plot(Px(i),Py(i),'-','color',C{i},'LineWidth',1.5);   
    end
    
    goalHandle = plot(Px,Py,'+','linewidth',5);
    currHandle = plot(Px,Py,'o','linewidth',5);
    titleHandle = title(['o = Robots, + = Goals, Iteration ', num2str(0)]);
    axis([0,10,0,10]);
end

if showPlot2
    fig = figure(3);
    childs = allchild(fig);
    errorHandle = plot(counter,dist(1),'-','linewidth',1,'color',C{1});
    hold on
    error2Handle = plot(counter,dist(2),'-','linewidth',1,'color',C{2});
    hold on 
    error3Handle = plot(counter,dist(3),'-','linewidth',1,'color',C{3});
    hold on 
    error4Handle = plot(counter,dist(4),'-','linewidth',1,'color',C{4});
    hold on  
    error5Handle = plot(counter,dist(5),'-','linewidth',1,'color',C{5});
    hold on
    error6Handle = plot(counter,dist(6),'-','linewidth',1,'color',C{6}); 
    hold on
    error7Handle = plot(counter,dist(7),'-','linewidth',1,'color',C{7}); 
    hold on
    error8Handle = plot(counter,dist(8),'-','linewidth',1,'color',C{8}); 
    hold on
    xlabel('Iterations');
    ylabel('position error');
    legend({'robot1','robot2','robot3','robot4','robot5','robot6','robot7','robot8'});     
end

if showPlot3
    fig = figure(4);
    childs = allchild(fig);
    formationHandle = plot(counter,240*(dist(1)+dist(2)+dist(3)+dist(4)+dist(5)+dist(6)+dist(7)+dist(8))/8,'-','linewidth',2);
    hold on
    xlabel('Iterations');
    ylabel('cost function');
end

figure
setMyColormap('cmocean_thermal.txt');
set(surf(ZZZ{1}),'LineStyle','none');
axis([0,100,0,100]);
set(2,'unit','centimeters','position',[1,2,11,11])

 
in_flag = 0;
dist = xrange*ones(n,1);
last_errx = zeros(n,1);
last_erry = zeros(n,1);
integralx = zeros(n,1);
integraly = zeros(n,1);
Voltagex = zeros(n,1);
Voltagey = zeros(n,1);

for tb=start:xin:length(ZZZ)
    if tb<length(ZZZ)
        thresh=0.5;
    end
    if tb==length(ZZZ)
        thresh=0.01;
    end
    ddist=ones(n,1);
    if tb==2 && fg==1
        for i=1:length(Px)
            oox(i)=Px(i);
            ooy(i)=Py(i);
            save ('Pxy.mat','oox','ooy');
        end
    end
    Z=1000.*ZZZ{tb};

    val2 = Z;
     figure(1)  
      while max(ddist)>thresh
        tic;
        counter = counter+1;
        [v,c]=VoronoiBounded(Px,Py, crs);
     
        for i = 1:numel(c) 
            
            BW = roipoly(Z,(10)*v(c{i},1),(10)*v(c{i},2));
            GI = mat2gray(BW);
            for m=1:100
                for j=1:100
                    GI(j,m) = GI(j,m)*val2(j,m);
                end
            end
            s = regionprops(BW, GI, {'WeightedCentroid'});
            cx{i} =min( s.WeightedCentroid(1,1)/(10));
            cy{i}= min(s.WeightedCentroid(1,2)/(10));
            cx{i}= min(xrange,max(0, cx{i}));
            cy{i} = min(yrange,max(0, cy{i}));
        end 
        
        for i = 1:numel(c)           
            if ~isnan(cx{i}) && inpolygon(cx{i},cy{i},crs(:,1),crs(:,2))
                PPx(i)=Px(i);
                PPy(i)=Py(i);
                if(Voltagex(i) > Umax &&  Voltagey(i) > Umax)
                    if(abs(cx{i} - Px(i))<max_speed || abs(cy{i}-Py(i))<max_speed)
                        in_flag = 1;
                        if(last_errx(i)<0)
                            integralx(i) = integralx(i) + last_errx(i);
                        end
                        if(last_erry(i)<0)
                            integraly(i) = integraly(i) + last_erry(i);
                        end
                    else
                        in_flag = 0;
                    end
                elseif(Voltagex(i) < Umin &&  Voltagey(i) < Umin)
                    if(abs(cx{i}- Px(i))<max_speed || abs(cy{i}-Py(i))<max_speed)
                        in_flag = 1;
                        if(last_errx(i)>0)
                            integralx(i) = integralx(i) + last_errx(i);
                        end
                        if(last_erry(i)>0)
                            integraly(i) = integraly(i) + last_erry(i);
                        end
                    else
                        in_flag = 0;
                    end
                else
                    if(abs(cx{i} - Px(i))<max_speed || abs(cy{i}-Py(i))<max_speed)
                        in_flag = 1;
                        integralx(i) = integralx(i) + last_errx(i);
                        integraly(i) = integraly(i) + last_erry(i);
                    else
                        in_flag = 0;
                    end
                end
                Voltagex(i) = Kprop*(cx{i}- Px(i)) + Ki * in_flag * integralx(i) + Kd * (cx{i} - Px(i) - last_errx(i));
                Voltagey(i) = Kprop*(cy{i} - Py(i)) + Ki * in_flag * integraly(i) + Kd * (cy{i} - Py(i) - last_erry(i));
                Px(i) = Px(i) + Voltagex(i);  
                Py(i) = Py(i) + Voltagey(i);
                
                
                last_errx(i) = cx{i} - Px(i);
                last_erry(i) = cy{i} - Py(i);                

                dist(i) = sqrt((cx{i} - Px(i))^2 + (cy{i} - Py(i))^2);
                
                ddist(i)=sqrt((cx{i} - Px(i))^2 + (cy{i} - Py(i))^2);
                lenth(i) = lenth(i)+ sqrt((Px(i) - PPx(i))^2 + (Py(i) - PPy(i))^2);
            end
        end
       line_x=[line_x;Px'];
       line_y=[line_y;Py'];
        
             averagedist = 0;
        fxi = (max(crs(:,1)) + min(crs(:,1)))/2 ;
        fyi = (max(crs(:,2)) + min(crs(:,2)))/2 ;
        for i = 1:numel(c)
            avdist(i) = sqrt((fxi - Px(i))^2 + (fyi - Py(i))^2);
            averagedist = averagedist + avdist(i);
        end
        
        if showPlot
            for i = 1:numel(c) 
                set(verCellHandle(i), 'XData',v(c{i},1),'YData',v(c{i},2));
            end
            set(titleHandle,'string',['o = Robots, + = Goals, Cycle', num2str(cycle,'%3d'), ', Iteration', num2str(counter,'%3d')]);
            set(goalHandle,'XData',Px,'YData',Py);
            axis equal
            axis([0,10,0,10]);
            set(1,'unit','centimeters','position',[30,2,11,11]);
            drawnow
        end
        time(counter,cycle) = toc;
        if showPlot
            set(currHandle,'XData',Px,'YData',Py);
            for i = 1:numel(Px) 
                xD = [get(pathHandle(i),'XData'),Px(i)];
                yD = [get(pathHandle(i),'YData'),Py(i)];
                set(pathHandle(i),'XData',xD,'YData',yD);
            end
        end   
        if showPlot2
            xD2=[get(errorHandle,'XData'),counter];
            yD2=[get(errorHandle,'YData'),dist(1)];
            xD3=[get(error2Handle,'XData'),counter];
            yD3=[get(error2Handle,'YData'),dist(2)];
            xD4=[get(error3Handle,'XData'),counter];
            yD4=[get(error3Handle,'YData'),dist(3)];
            xD5=[get(error4Handle,'XData'),counter];
            yD5=[get(error4Handle,'YData'),dist(4)];
            xD6=[get(error5Handle,'XData'),counter];
            yD6=[get(error5Handle,'YData'),dist(5)];
            xD7=[get(error6Handle,'XData'),counter];
            yD7=[get(error6Handle,'YData'),dist(6)];
            xD8=[get(error7Handle,'XData'),counter];
            yD8=[get(error7Handle,'YData'),dist(7)];
            xD9=[get(error8Handle,'XData'),counter];
            yD9=[get(error8Handle,'YData'),dist(8)];
            set(errorHandle,'XData',xD2,'YData',yD2);
            set(error2Handle,'XData',xD3,'YData',yD3);
            set(error3Handle,'XData',xD4,'YData',yD4);
            set(error4Handle,'XData',xD5,'YData',yD5);
            set(error5Handle,'XData',xD6,'YData',yD6);
            set(error6Handle,'XData',xD7,'YData',yD7);
            set(error7Handle,'XData',xD6,'YData',yD6);
            set(error8Handle,'XData',xD7,'YData',yD7);
      end

      if showPlot3
          fx=[get(formationHandle,'XData'),counter];
          fy=[get(formationHandle,'YData'),1*(dist(1)+dist(2)+dist(3)+dist(4)+dist(5)+dist(6)+dist(7)+dist(8))/8];
          set(formationHandle,'XData',fx,'YData',fy);
      end
      end
    if tb<length(ZZZ)   
        cycle=cycle+1;
        Z=ZZZ{tb+xin};
        figure(5)
        setMyColormap('cmocean_thermal.txt') 
        surf(Z);
        set(surf(Z),'LineStyle','none');
        axis([0,100,0,100]);
        set(5,'unit','centimeters','position',[1,2,11,11]);
    end

end
addlenth=0;
for i=1:n
    addlenth=addlenth+lenth(i);
end