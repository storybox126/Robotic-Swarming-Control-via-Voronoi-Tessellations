%Chapter 4��Multi-Robot Formation Switching Based on Voronoi Tessellations

clc
close all
clear all


N = 101; 
epsilon = 1;



P = 2;
H = zeros(N*N,P);


ZZZ={};
X1 = 0 : 0.01 : 1;
Y1 = 0 : 0.01 : 1;
 [ XX, YY ] = meshgrid( X1, Y1 );

ZZZ{2}=exp((-1)*2*(10*(YY-0.4)).^2);

ZZZ{6}=exp(-1*0.1*(100*(XX-0.5).^2+100*(YY-0.5).^2- (10*0.3)^2).^2);


surf(ZZZ{1})
axis([0,100,0,100,0,1]);
shading flat;

ZZZ{1}=ZZZ{2};
ZZZ{2}=ZZZ{6};

for i=1:P
    A = ZZZ{i};
    H(:,i) = A(:);
end

rep = 'F:/test/wb_cvt/results/tt03/';

mkdir(rep);

n = size(H,1);
areaWeights = ones(n,1)/n;
H = H*n;

entropies = -sum(bsxfun(@times,H.*log(H),areaWeights),1);
maxEntropy = max(entropies); 


imS = [N N];
if exist('imfilter') && 0
    
    h = fspecial('gaussian',[1 max(imS)],epsilon);
    h = h / sum(h);
    imBlur = @(x) imfilter(imfilter(x,h,'replicate'),h','replicate');
else
    blur = load_filtering('imgaussian', N);
    imBlur = @(x)blur(x,epsilon);
end

imagesc(imBlur(reshape(H(:,1),imS)));

blurColumn = @(x) reshape(imBlur(reshape(x,imS)),[],1);
blurAll2 = @(x) cell2mat(cellfun(blurColumn, num2cell(x,1), 'UniformOutput', false));
blurAll = @(x) blurAll2(blurAll2(x));



imagesc(reshape(blurAll(H(:,1)),imS));
axis equal;
axis off;


q=20;
t = linspace(0,1,q);
[T,S] = meshgrid(t,t); 
S = S(:); 
T = T(:);
W = [(1-S).*(1-T) S.*(1-T)]';
Q = size(W,2);



entropyLimit = Inf; 
steps = linspace(0,1,5);

averages = cell(length(steps),length(steps));
barycenters = cell(length(steps),length(steps));

options.niter = 100; 
options.verb = 1;
options.tol = 1e-15; 
resh = @(x)reshape(x, imS);
options.disp = @(x)imageplot(-resh(x));

B = {};
for i=1:q
        w = W(:,i)';
        w = w/sum(w);
        B{i} = convolutionalBarycenter(H,w,areaWeights,blurAll,blurAll,entropyLimit,options); 
        
        if isnan(sum(B{end}))
            warning('Problem');
            break;
        end
        
        u= rescale(resh(B{i}));
        ZD{i}=u;
        clf; imageplot(u); drawnow;
        
        imwrite(u, [rep 'measure-' num2str(i) '.png'], 'png');
end

save ('line_to_ring_icgnc6.mat','ZD')
for i=1:q
    figure()
    surf(ZD{i});
    set(surf(ZD{i}),'LineStyle','none');
    axis([0,100,0,100]);
    set(gcf,'unit','centimeters','position',[1,2,12,11]);
end   