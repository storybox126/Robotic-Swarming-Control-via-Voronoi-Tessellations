%Chapter 5��Multi-Robot Safety and Collision Avoidance Based on Voronoi Tessellations
%Code by Kai Cao��XATU

clc
close all
clear all
n=10;
CRS=10;
M=[];
step=0.01;
ob=ceil((CRS/step)/2);
isob=0;
Ans_ob=zeros(CRS/step,CRS/step);
crs = [0,0;0,CRS;CRS,CRS;CRS,0];

x=(step:step:10);
y=(step:step:10);
r=[0.2,0.2,0.2,0.2,0.2,0.2,0.2,0.2,0.2,0.2];
rc=10;%
lamd=[0.55,0.55,0.55,0.55,0.55,0.8,0.8,0.8,0.8,0.8]*0.5;
theta=0:pi/100:2*pi;
for i=1:n
xc(i,:)=r(i)*cos(theta); yc(i,:)=r(i)*sin(theta); 
xcl(i,:)=lamd(i)*cos(theta); ycl(i,:)=lamd(i)*sin(theta);  
rxcl(i,:)=2*rc*cos(theta); rycl(i,:)=2*rc*sin(theta);  
end
guiji=1;
C = {[0.2,0.6,1],[1,0.5,0],[1,0.9,0],[0.5,0.2,1],[0.2,0.6,1]*0.5,[1,0.5,0]*0.5,[1,0.9,0]*0.5,[0.5,0.2,1]*0.5,[0.6,0.6,1],[1,0.5,1]};  % �����ȣ��ƣ��ϵ�rgbֵ
showPlot = 1;
showPlot2 = 1;
showPlot3 = 1;
showPlot4 = 1;
Px = [0.5;0.5;0.5;1.5;1.5;1.5;0.5;0.5;1.5;1.5];
Py = [1;2;3;1;2;3;5;6;4;6];
xrange = max(crs(:,1));
yrange = max(crs(:,2));
[ XX, YY ] = meshgrid( x, y );
mu=[8 8];

sigma = 1;

  Z = ones(CRS/step,CRS/step);
[x1,y1]=meshgrid(step :step: CRS );

for i=1:1000
    for j=1:20
            Z(i,j)=0;
    end
    for j=980:1000
            Z(i,j)=0;
    end
end
for j=1:1000
    for i=1:20
            Z(i,j)=0;
    end
    for i=980:1000
            Z(i,j)=0;
    end
end

figure,pcolor(XX, YY, Z);
shading interp;

axis([0,xrange,0,yrange]);
in_flag = 0;
dist = zeros(n+1,1);
last_errx = zeros(n+1,1);
last_erry = zeros(n+1,1);
Voltagex = zeros(n+1,1);
Voltagey = zeros(n+1,1);
max_speed = 1;
Umax = 1;
Umin = -0.5;
Kprop = 0.4; 
Ki = 0.015;
Kd = 0.2;
counter =0;
Px_plot=[];
Py_plot=[];
if showPlot2
    fig = figure(3);
    childs = allchild(fig);
    errorHandle = plot(counter,dist(1),'-','linewidth',1.5);
    hold on
    errorHandle = plot(counter,dist(1),'-','linewidth',1.5,'color',C{1});
    hold on
    error2Handle = plot(counter,dist(2),'-','linewidth',1.5,'color',C{2});
    hold on 
    error3Handle = plot(counter,dist(3),'-','linewidth',1.5,'color',C{3});
    hold on 
    error4Handle = plot(counter,dist(4),'-','linewidth',1.5,'color',C{4});
    hold on  
    error5Handle = plot(counter,dist(5),'-','linewidth',1.5,'color',C{5});
    hold on
    error6Handle = plot(counter,dist(6),'-','linewidth',1.5,'color',C{6});
    hold on 
    error7Handle = plot(counter,dist(7),'-','linewidth',1.5,'color',C{7});
    hold on 
    error8Handle = plot(counter,dist(8),'-','linewidth',1.5,'color',C{8});
    hold on 
    error9Handle = plot(counter,dist(9),'-','linewidth',1.5,'color',C{9});
    hold on
    error10Handle = plot(counter,dist(10),'-','linewidth',1.5,'color',C{10});
    hold on 
    axis auto
    xlabel('Iterations');
    ylabel('Position Error');
    legend({'robot1','robot2','robot3','robot4','robot5','robot6','robot7','robot8','robot9','robot10'});  
end
    if showPlot3
    fig = figure(4);
    childs = allchild(fig);
    formationHandle = plot(counter,dist(1),'-','linewidth',2);
    hold on
    xlabel('Iterations');
    ylabel('Cost Function');
    end
 M1=zeros(1,n);
if showPlot4
    fig = figure(5);
    childs = allchild(fig);
     mHandle = plot(counter,M1(1),'-','linewidth',1.5,'color',C{1});
    hold on
    m2Handle = plot(counter,M1(2),'-','linewidth',1.5,'color',C{2});
    hold on 
    m3Handle = plot(counter,M1(3),'-','linewidth',1.5,'color',C{3});
    hold on 
    m4Handle = plot(counter,M1(4),'-','linewidth',1.5,'color',C{4});
    hold on  
    m5Handle = plot(counter,M1(5),'-','linewidth',1.5,'color',C{5});
    hold on
    m6Handle = plot(counter,M1(6),'-','linewidth',1.5,'color',C{6});
    hold on 
    m7Handle = plot(counter,M1(7),'-','linewidth',1.5,'color',C{7});
    hold on 
    m8Handle = plot(counter,M1(8),'-','linewidth',1.5,'color',C{8});
    hold on 
    m9Handle = plot(counter,M1(9),'-','linewidth',1.5,'color',C{9});
    hold on
    m10Handle = plot(counter,M1(10),'-','linewidth',1.5,'color',C{10});
    hold on 
    axis auto
    xlabel('Iterations');
    ylabel('Area Of Voronoi');
    legend({'robot1','robot2','robot3','robot4','robot5','robot6','robot7','robot8','robot9','robot10'});  

end
 averagedist=0;
 lamd=[0.55,0.55,0.55,0.55,0.55,0.8,0.8,0.8,0.8,0.8]*0.8;
  while max(dist(1:n))>0.002||counter==0

      counter = counter+1
            
            for i=1:n
                PX{i}=repmat( Px(i) , CRS/step , CRS/step );
                PY{i}=repmat( Py(i) , CRS/step , CRS/step );
                Dis{i}=sqrt([PX{i}-XX].*[PX{i}-XX]+[PY{i}-YY].*[PY{i}-YY]);                                       
            end
                        
            for i=1:n
                 CAT(:,:,i)=Dis{i};
                 for j=1:n                    
                     if i~=j&&(sqrt((Px(i)-Px(j))^2+(Py(i)-Py(j))^2)<=2*rc)
                       CAT(:,:,j)=Dis{j}-((1+0.5*(lamd(i)-lamd(j)))*(r(i)+r(j))-0.5*(lamd(i)-lamd(j))*(sqrt([Px(i,:)-Px(j,:)]^2+[Py(i,:)-Py(j,:)]^2)));
                       Dis2Neb{counter}(i,j)=sqrt((Px(i) - Px(j))^2 + (Py(i)- Py(j))^2);
                     else if sqrt((Px(i)-Px(j))^2+(Py(i)-Py(j))^2)>2*rc
                             CAT(:,:,j)=Dis{j}*100000;
                         end
                     end
                 end
             [CC{i},II{i}]=min(CAT,[],3);
             clear CAT;
            end
    
     Ans=zeros(CRS/step,CRS/step);      
     if counter==1&&isob
         Ans_ob=zeros(CRS/step,CRS/step);
        for j=1:CRS/step
         for k=1:CRS/step   

           if x1(j,k)>4&&x1(j,k)<6&&y1(j,k)>3&&y1(j,k)<8
             Ans_ob(j,k)=-100;                                
           end

         end
        end
     end
       for i=1:n
           II{i}(~(II{i}==i))=0;
       end 
        for i=1:n
              for j=1:CRS/step
                  for k=1:CRS/step   
                      if II{i}(j,k)==i&&(sqrt((Px(i)-x1(j,k))^2+(Py(i)-y1(j,k))^2)>rc)                          
                          II{i}(j,k)=0;
                      end  
                  end
              end
        end 
       for i=1:n
            Ans=Ans+II{i};
       end 
       clear II;
       Ans=Ans+1*Ans_ob;
       Ans(Ans<0)=-1;  
               for i=1:n                     
                      [h{i}(:,1),h{i}(:,2)]=find(Ans==i);  
               end
        H=zeros(2,n); 
        M1=zeros(1,n);
        M2=zeros(1,n);
        M3=zeros(1,n);
        for j=1:n
            for i=1:size(h{j},1)
                H(1,j)=H(1,j)+x1(h{j}(i,1),h{j}(i,2));
                H(2,j)=H(2,j)+y1(h{j}(i,1),h{j}(i,2));                
                M1(1,j)=M1(1,j)+Z(floor(x1(h{j}(i,1),h{j}(i,2))/step),floor(y1(h{j}(i,1),h{j}(i,2))/step));
                M2(1,j)=M2(1,j)+(x1(h{j}(i,1),h{j}(i,2)))*Z(floor(x1(h{j}(i,1),h{j}(i,2))/step),floor(y1(h{j}(i,1),h{j}(i,2))/step));
                M3(1,j)=M3(1,j)+(y1(h{j}(i,1),h{j}(i,2)))*Z(floor(x1(h{j}(i,1),h{j}(i,2))/step),floor(y1(h{j}(i,1),h{j}(i,2))/step));
                 
            end
            if M1(1,j)==0
                    M1(1,j)=size(h{j},1);
                    M2(1,j)=H(1,j);
                    M3(1,j)=H(2,j);
            end
%               
              M(counter,j)=size(h{j},1);
              H_av(3,j)=M2(1,j)/M1(1,j);
              H_av(4,j)=M3(1,j)/M1(1,j);
        end
            CX=H_av(3,:);
            CY=H_av(4,:);
            Px_last=Px;
            Py_last=Py;
     
        if counter ==1
           figure 
           contourf(Ans);
           set(gca, 'XTick', [100,200,300,400,500,600,700,800,900,1000] );
           set(gca,'XTickLabel',{'1','2','3','4','5','6','7','8','9','10'})
           set(gca, 'YTick', [100,200,300,400,500,600,700,800,900,1000] );
           set(gca,'YTickLabel',{'1','2','3','4','5','6','7','8','9','10'})
           title(['o = Robots, + = Goals, Iteration ', num2str(counter-1)]);
           hold on          
           plot(Px*100,Py*100,'k.','Linewidth',1.5,'MarkerSize',10);hold on
           for i=1:n                
                    fill(xc(i,:)*100+Px(i)*100, yc(i,:)*100+Py(i)*100,'k')                    
                    hold on
                    plot(Px(i)*100+xcl(i,:)*100,Py(i)*100+ycl(i,:)*100,'r-','Linewidth',1,'MarkerSize',10);
                    hold on

           end
           plot(CX*100,CY*100,'r+','linewidth',1,'MarkerSize',8);
           hold on 
           Px_plot=[Px_plot,Px];
           Py_plot=[Py_plot,Py];
           axis([0,1000,0,1000]);
           axis square;

        end   

         for i=1:n   
         
                Voltagex(i) = Kprop*(CX(i) - Px(i));%+Kd*(CX(i) - Px(i)-last_errx(i)) ;
                Voltagey(i) = Kprop*(CY(i) - Py(i));%+Kd*(CY(i) - Py(i)-last_erry(i)) ;
                if  Voltagex(i) > Umax 
                    Voltagex(i)=0.5*Kprop*(CX(i) - Px(i));                    
                end

                if  Voltagey(i) > Umax 
                    Voltagey(i)=0.5*Kprop*(CY(i) - Py(i));                    
                end

                Px(i) = Px(i) + Voltagex(i) ;  
                Py(i) = Py(i) + Voltagey(i);
                last_errx(i) = CX(i) - Px(i);
                last_erry(i) = CY(i) - Py(i);
                dist(i) = sqrt((CX(i) - Px(i))^2 + (CY(i) - Py(i))^2);
         end
         averagedist = 0;

        for i = 1:n
            averagedist = averagedist +  dist(i)*Z(ceil(CX(i)*100),ceil(CY(i)*100));
        end
                  figure

                contourf(Ans);
           set(gca, 'XTick', [100,200,300,400,500,600,700,800,900,1000] );
           set(gca,'XTickLabel',{'1','2','3','4','5','6','7','8','9','10'})
           set(gca, 'YTick', [100,200,300,400,500,600,700,800,900,1000] );
           set(gca,'YTickLabel',{'1','2','3','4','5','6','7','8','9','10'})
                title(['o = Robots, + = Goals, Iteration ', num2str(counter)]);
                hold on 


                plot(Px*100,Py*100,'k.','Linewidth',1.5,'MarkerSize',15);hold on
                 for i=1:n                
                    plot(Px(i)*100+xc(i,:)*100,Py(i)*100+yc(i,:)*100,'k-','Linewidth',1,'MarkerSize',10);
                    fill(xc(i,:)*100+Px(i)*100, yc(i,:)*100+Py(i)*100,'k')                    
                    hold on
                    plot(Px(i)*100+xcl(i,:)*100,Py(i)*100+ycl(i,:)*100,'r-','Linewidth',1,'MarkerSize',10);
                    hold on

                 end
                plot(CX*100,CY*100,'r+','linewidth',1,'MarkerSize',8);
                hold on
                 axis([0,1000,0,1000]);
                 axis square;
                Px_plot=[Px_plot,Px];
                Py_plot=[Py_plot,Py];
      for i=1:n
         for j=1:n
             if i~=j
                Dis2Neb{counter}(i,j)=sqrt((Px(i) - Px(j))^2 + (Py(i)- Py(j))^2);
             end
         end 
      end
                if counter>=1&&guiji
                  for j=1:size(Px_plot,2)-1
                     for i=1:n                    
                       plot([Px_plot(i,j)*100 Px_plot(i,j+1)*100],[Py_plot(i,j)*100 Py_plot(i,j+1)*100],'color',C{i},'linewidth',1.5);
                       hold on 
                     end
                  end
                end

           if showPlot2
            xD2=[get(errorHandle,'XData'),counter];
            yD2=[get(errorHandle,'YData'),dist(1)];
            xD3=[get(error2Handle,'XData'),counter];
            yD3=[get(error2Handle,'YData'),dist(2)];
            xD4=[get(error3Handle,'XData'),counter];
            yD4=[get(error3Handle,'YData'),dist(3)];
            xD5=[get(error4Handle,'XData'),counter];
            yD5=[get(error4Handle,'YData'),dist(4)];
             xD6=[get(error5Handle,'XData'),counter];
            yD6=[get(error5Handle,'YData'),dist(5)];
            xD7=[get(error6Handle,'XData'),counter];
            yD7=[get(error6Handle,'YData'),dist(6)];
            xD8=[get(error7Handle,'XData'),counter];
            yD8=[get(error7Handle,'YData'),dist(7)];
            xD9=[get(error8Handle,'XData'),counter];
            yD9=[get(error8Handle,'YData'),dist(8)];
            xD10=[get(error9Handle,'XData'),counter];
            yD10=[get(error9Handle,'YData'),dist(9)];
            xD11=[get(error10Handle,'XData'),counter];
            yD11=[get(error10Handle,'YData'),dist(10)];
            set(errorHandle,'XData',xD2,'YData',yD2);
            set(error2Handle,'XData',xD3,'YData',yD3);
            set(error3Handle,'XData',xD4,'YData',yD4);
            set(error4Handle,'XData',xD5,'YData',yD5);
            set(error5Handle,'XData',xD6,'YData',yD6);
            set(error6Handle,'XData',xD7,'YData',yD7);
            set(error7Handle,'XData',xD8,'YData',yD8);
            set(error8Handle,'XData',xD9,'YData',yD9);
            set(error9Handle,'XData',xD10,'YData',yD10);
            set(error10Handle,'XData',xD11,'YData',yD11);
           end
        if showPlot3
             fx=[get(formationHandle,'XData'),counter];
             if (counter <= 89)
                fy=[get(formationHandle,'YData'),averagedist];
             else
                 fy=[get(formationHandle,'YData'),averagedist];
             end
            set(formationHandle,'XData',fx,'YData',fy);
        end
            hold on
            drawnow 
              if showPlot2
            xD2=[get(mHandle,'XData'),counter];
            yD2=[get(mHandle,'YData'),M(counter,1)/1000000];
            xD3=[get(m2Handle,'XData'),counter];
            yD3=[get(m2Handle,'YData'),M(counter,2)/1000000];
            xD4=[get(m3Handle,'XData'),counter];
            yD4=[get(m3Handle,'YData'),M(counter,3)/1000000];
            xD5=[get(m4Handle,'XData'),counter];
            yD5=[get(m4Handle,'YData'),M(counter,4)/1000000];
            xD6=[get(m5Handle,'XData'),counter];
            yD6=[get(m5Handle,'YData'),M(counter,5)/1000000];
            xD7=[get(m6Handle,'XData'),counter];
            yD7=[get(m6Handle,'YData'),M(counter,6)/1000000];
            xD8=[get(m7Handle,'XData'),counter];
            yD8=[get(m7Handle,'YData'),M(counter,7)/1000000];
            xD9=[get(m8Handle,'XData'),counter];
            yD9=[get(m8Handle,'YData'),M(counter,8)/1000000];
            xD10=[get(m9Handle,'XData'),counter];
            yD10=[get(m9Handle,'YData'),M(counter,9)/1000000];
            xD11=[get(m10Handle,'XData'),counter];
            yD11=[get(m10Handle,'YData'),M(counter,10)/1000000];
            set(mHandle,'XData',xD2,'YData',yD2);
            set(m2Handle,'XData',xD3,'YData',yD3);
            set(m3Handle,'XData',xD4,'YData',yD4);
            set(m4Handle,'XData',xD5,'YData',yD5);
            set(m5Handle,'XData',xD6,'YData',yD6);
            set(m6Handle,'XData',xD7,'YData',yD7);
            set(m7Handle,'XData',xD8,'YData',yD8);
            set(m8Handle,'XData',xD9,'YData',yD9);
            set(m9Handle,'XData',xD10,'YData',yD10);
            set(m10Handle,'XData',xD11,'YData',yD11);

           end
clear h;
clear Ans1;
  end

for i=2:counter
    Dis2Neb{i-1}=Dis2Neb{i};
end
for i=1:counter
    Dis2Neb{1,i}(Dis2Neb{1,i}==0)=100;
    Dis2Neb{2,i}=min(Dis2Neb{1,i}');
end
figure
for i=1:counter-1
    for j=1:n
    plot([i i+1],[Dis2Neb{2,i}(j) Dis2Neb{2,i+1}(j)],'color',C{j},'linewidth',1.5);
    hold on
    end
end
 xlabel('Iterations');
 ylabel('Distance to Nearest Robot');
legend({'robot1','robot2','robot3','robot4','robot5','robot6','robot7','robot8','robot9','robot10'});  
axis square
