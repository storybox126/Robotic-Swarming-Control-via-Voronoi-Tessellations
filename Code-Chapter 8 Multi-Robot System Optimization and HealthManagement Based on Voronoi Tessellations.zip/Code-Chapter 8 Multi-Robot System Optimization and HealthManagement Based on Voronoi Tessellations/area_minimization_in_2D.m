%Chapter 8:Multi-Robot System Optimization and HealthManagement Based on Voronoi tessellation
%Code by Kai Cao��XATU

clear all
close all
clc

pursuers_num=5; 
evaders_num=1; 
agents_sum=pursuers_num+evaders_num; 
t_step=0.02; 
capture_dis=0.1; 
counter=0;
L=10; 
square_x=[0 0 L L 0]; 
square_y=[0 L L 0 0];



agents_pos = [9.5237,0.5417;4.9369,0.9905;3.1170,8.7613;7.1683,4.4139;8.4722,3.3593;1.4,2.5];
agents_pos = [0.5417,9.5237;0.9905,4.9369;8.7613,3.1170;4.4139,7.1683;3.3593,8.4722;8.5,8.4];
for i=1:agents_sum
    agents(i).pos=agents_pos(i,:);
    agents(i).active=1; 
    agents(i).min_dis=100;
    agents(i).dis = 0;
end
dist = pursuers_num*ones(pursuers_num,1);
counter = 0;

figure
 fig = figure;
    childs = allchild(fig);

    errorHandle = plot(counter,agents(1).dis,'-','linewidth',2);
    hold on
    error2Handle = plot(counter,agents(2).dis,'-','linewidth',2);
    hold on 
    error3Handle = plot(counter,agents(3).dis,'-','linewidth',2);
    hold on 
    error4Handle = plot(counter,agents(4).dis,'-','linewidth',2);
    hold on
    error5Handle = plot(counter,agents(5).dis,'-','linewidth',2);
    hold on
    figure
while(sum([agents(pursuers_num+1:agents_sum).active])~=0) 
    
    counter = counter + 1;
        temp_pos=[];
       
        index_active=[agents(:).active]; 
        index_active = find(index_active);
        temp_pos=[agents(index_active).pos];
        temp_pos=reshape(temp_pos,2,length(index_active))'; 
        [vx,vy] = voronoi(temp_pos(:,1),temp_pos(:,2)); 
        [V,C] = voronoin(temp_pos); 
        
        
        plot(temp_pos(1:pursuers_num,1),temp_pos(1:pursuers_num,2),'gs',... 
             temp_pos(pursuers_num+1:length(index_active),1),temp_pos(pursuers_num+1:length(index_active),2),'rp',... 
            'LineWidth',1.5,'Markersize',10);
        hold on;
        plot(vx,vy,'k-','LineWidth',1.5);
        hold on;
        
       
        plabels = arrayfun(@(n) {sprintf('P%d', n)}, (1:length(index_active))');
        hold on
        Hpl = text(temp_pos(:,1), temp_pos(:,2), plabels, ...
              'HorizontalAlignment','left', ...
              'BackgroundColor', 'none');
        xlim([0 L]);
        ylim([0 L]);
        
       
        for i=1:length(C)
            out_index=[];
            inf_index=[];
            if sum(C{i}==1) 
                inf_index=find(C{i}==1);
            end
            for j=1:length(C{i}) 
                [in on]= inpolygon(V(C{i}(j),1),V(C{i}(j),2),square_x,square_y);
                if in==0 && on==0 
                    out_index=[out_index j];
                end
            end
            out_index=[inf_index out_index]; 
            C{i}(out_index)=[]; 
        end
        
        
        cross_point=[];
        for i=1:length(vx)
            [xi,yi] = polyxpoly(vx(:,i),vy(:,i),square_x,square_y,'unique');
            cross_point=[cross_point;[xi yi]];
        end
        
       
        old_V=V;
        V=[V;cross_point];
        
        
        C_pos=temp_pos; 
        for i=length(old_V)+1:length(V)
            V_dist=sum(abs(V(i,:)-C_pos).^2,2).^(1/2); 
            V_index=find(V_dist==min(V_dist)); 
            if length(V_index)==2
                C{V_index(1)}=[C{V_index(1)} i];
                C{V_index(2)}=[C{V_index(2)} i];
            else
                C{V_index}=[C{V_index} i];
                V_dist(V_index)=max(V_dist); 
                V_index=find(V_dist==min(V_dist)); 
                C{V_index}=[C{V_index} i];
            end
        end
        
        
        square=[square_x;square_y]';
        square(end,:)=[]; 
        old_V=V;
        V=[V; square];
        for i=length(old_V)+1:length(V)
            V_dist=sum(abs(V(i,:)-C_pos).^2,2).^(1/2);
            V_index=find(V_dist==min(V_dist)); 
            if length(V_index)==2
                C{V_index(1)}=[C{V_index(1)} i];
                C{V_index(2)}=[C{V_index(2)} i];
            else
                C{V_index}=[C{V_index} i]; 
            end
        end
        
        
        common_index=[]; 
        common_id=[]; 
        for i=1:length(C) 
            for j=1:length(C)
                if i~=j
                    temp_common=intersect(C{i},C{j});
                    if length(temp_common)==2
                        common_index=[common_index;temp_common];
                        common_id=[common_id;j];
                    end
                end
            end
            if length(common_id)~=0 
                agents(i).neightbor.id=common_id; 
                agents(i).neightbor.shared_boundary=common_index; 
                agents(i).neightbor.mid_point= (V(common_index(:,1),:) + V(common_index(:,2),:))/2;  
                common_index=[]; 
                common_id=[];
            end
            find_index = find(agents(i).neightbor.id==6);
            if find_index
                agents(i).shared_boundary_length = sqrt((V(agents(i).neightbor.shared_boundary(find_index,1),1)-V(agents(i).neightbor.shared_boundary(find_index,2),1))^2 + ...
                                    (V(agents(i).neightbor.shared_boundary(find_index,1),2)-V(agents(i).neightbor.shared_boundary(find_index,2),2))^2);
            end
        end
        total_length = 0;
        for i = 1 : pursuers_num
           if isempty(agents(i).shared_boundary_length)
               agents(i).shared_boundary_length = 0;
           end
           total_length = total_length + agents(i).shared_boundary_length;
        end

        
       
        for i=1:pursuers_num
            if sum(agents(i).neightbor.id>pursuers_num) 
                near_id=find(agents(i).neightbor.id>pursuers_num); 
                temp_err=agents(i).pos-agents(i).neightbor.mid_point(near_id,:);
                temp_dis=sum(abs(temp_err).^2,2).^(1/2);
                min_index = find(temp_dis==min(min(temp_dis))) + sum(agents(i).neightbor.id<=pursuers_num); 
                agents(i).target=agents(i).neightbor.mid_point(min_index,:); 
                agents(i).up=(agents(i).target-agents(i).pos)/norm((agents(i).target-agents(i).pos));
                agents(i).limit = sqrt((agents(i).target(1)-agents(6).pos(1))^2 + (agents(i).target(2)-agents(6).pos(2))^2);
                agents(i).dis = sqrt((agents(i).pos(1)-agents(6).pos(1))^2 + (agents(i).pos(2)-agents(6).pos(2))^2);

            else 
                for j=(pursuers_num+1):agents_sum
                    if agents(j).active
                        dis=norm(agents(i).pos - agents(j).pos);
                        if dis < agents(i).min_dis
                            agents(i).min_dis=dis; 
                            agents(i).target=agents(j).pos;
                            agents(i).up=(agents(i).target-agents(i).pos)/norm((agents(i).target-agents(i).pos));
                            agents(i).limit = sqrt((agents(i).pos(1)-agents(6).pos(1))^2 + (agents(i).pos(2)-agents(6).pos(2))^2);
                            agents(i).dis = sqrt((agents(i).pos(1)-agents(i).target(1))^2 + (agents(i).pos(2)-agents(i).target(2))^2);
                        end
                    end
                end
            end
        end
  
        angle(1) = treeP_A(agents(1).pos(1),agents(1).pos(2),agents(6).pos(1),agents(6).pos(2),agents(5).pos(1),agents(5).pos(2));
        angle(2) = treeP_A(agents(5).pos(1),agents(5).pos(2),agents(6).pos(1),agents(6).pos(2),agents(3).pos(1),agents(3).pos(2));
        angle(3) = treeP_A(agents(3).pos(1),agents(3).pos(2),agents(6).pos(1),agents(6).pos(2),agents(2).pos(1),agents(2).pos(2));
        angle(4) = treeP_A(agents(2).pos(1),agents(2).pos(2),agents(6).pos(1),agents(6).pos(2),agents(4).pos(1),agents(4).pos(2));
        angle(5) = treeP_A(agents(4).pos(1),agents(4).pos(2),agents(6).pos(1),agents(6).pos(2),agents(1).pos(1),agents(1).pos(2));

        plot([agents(3).pos(1,1);agents(3).target(1,1)], [agents(3).pos(1,2);agents(3).target(1,2)],'r-.','linewidth',1.5)
        plot([agents(4).pos(1,1);agents(4).target(1,1)], [agents(4).pos(1,2);agents(4).target(1,2)],'r-.','linewidth',1.5)
        plot([agents(2).pos(1,1);agents(2).target(1,1)], [agents(2).pos(1,2);agents(2).target(1,2)],'b-','linewidth',1.0)
        plot([agents(1).pos(1,1);agents(1).target(1,1)], [agents(1).pos(1,2);agents(1).target(1,2)],'b-','linewidth',1.0)
        plot([agents(5).pos(1,1);agents(5).target(1,1)], [agents(5).pos(1,2);agents(5).target(1,2)],'r-.','linewidth',1.5)

        for i=1:pursuers_num
            if find(agents(i).neightbor.id ==6)
               agents(i).pos =agents(i).pos + t_step*agents(i).up;
               dist(i) = sqrt((agents(i).pos(1) - agents(pursuers_num+1).pos(1))^2 + (agents(i).pos(2) - agents(pursuers_num+1).pos(2))^2); % ������Ŀ���ľ���
            else
                agents(i).pos =agents(i).pos + t_step*agents(i).up;
            end
        end
       
        for i=(pursuers_num+1):agents_sum
            if agents(i).active
                for j=1:pursuers_num
                    dis=norm(agents(i).pos - agents(j).pos); 
                    if dis < agents(i).min_dis
                        agents(i).min_dis=dis; 
                    end
                end
                
                if agents(i).min_dis < capture_dis
                    agents(i).active=0;
                    for j=1:pursuers_num
                        agents(j).min_dis=100;
                    end
                    hold on
                    plot(agents(i).pos(1,1),agents(i).pos(1,2),'g*','LineWidth',2)
                end
            end
        end
    hold off
    pause(0.01)
            xD2=[get(errorHandle,'XData'),counter];
            yD2=[get(errorHandle,'YData'),agents(1).dis];
            xD3=[get(error2Handle,'XData'),counter];
            yD3=[get(error2Handle,'YData'),agents(2).dis];
            xD4=[get(error3Handle,'XData'),counter];
            yD4=[get(error3Handle,'YData'),agents(3).dis];
            xD5=[get(error4Handle,'XData'),counter];
            yD5=[get(error4Handle,'YData'),agents(4).dis];
            xD6=[get(error5Handle,'XData'),counter];
            yD6=[get(error5Handle,'YData'),agents(5).dis];

            set(errorHandle,'XData',xD2,'YData',yD2);
            set(error2Handle,'XData',xD3,'YData',yD3);
            set(error3Handle,'XData',xD4,'YData',yD4);
            set(error4Handle,'XData',xD5,'YData',yD5);
            set(error5Handle,'XData',xD6,'YData',yD6);

            angles(1,counter) = treeP_A(agents(5).pos(1),agents(5).pos(2),agents(6).pos(1),agents(6).pos(2),agents(3).pos(1),agents(3).pos(2))+...
                treeP_A(agents(1).pos(1),agents(1).pos(2),agents(6).pos(1),agents(6).pos(2),agents(5).pos(1),agents(5).pos(2))+...
                treeP_A(agents(4).pos(1),agents(4).pos(2),agents(6).pos(1),agents(6).pos(2),agents(1).pos(1),agents(1).pos(2))+...
                treeP_A(agents(2).pos(1),agents(2).pos(2),agents(6).pos(1),agents(6).pos(2),agents(4).pos(1),agents(4).pos(2))+...
                treeP_A(agents(3).pos(1),agents(3).pos(2),agents(6).pos(1),agents(6).pos(2),agents(2).pos(1),agents(2).pos(2));
end
