%Chapter 6: Multi-Robot Source Search and Coverage Control Based on Voronoi Tessellations
%Code by Kai Cao，XATU

clc
close all
clear all
n=7;
CRS=100;
M=[];
step=1;
ob=ceil((CRS/step)/2);
isob=0;
Ans_ob=zeros(CRS/step,CRS/step);
crs = [0,0;0,CRS;CRS,CRS;CRS,0];

x=(0.01:1:100);%
y=(0.01:1:100);
r=[0.2,0.2,0.2,0.2,0.2,0.2,0.2,0.2,0.2,0.2]*0;
rc=10;
lamd=[0.55,0.55,0.55,0.55,0.55,0.8,0.8,0.8,0.8,0.8]*0.5*0;
theta=0:pi/100:2*pi;
for i=1:n
xc(i,:)=r(i)*cos(theta); yc(i,:)=r(i)*sin(theta);
xcl(i,:)=lamd(i)*cos(theta); ycl(i,:)=lamd(i)*sin(theta);  
rxcl(i,:)=2*rc*cos(theta); rycl(i,:)=2*rc*sin(theta);  
end
guiji=1;
C = {[0.2,0.6,1],[1,0.5,0],[1,0.9,0],[0.5,0.2,1],[0.2,0.6,1]*0.5,[1,0.5,0]*0.5,[1,0.9,0]*0.5,[0.5,0.2,1]*0.5,[0.6,0.6,1],[1,0.5,1]}; 
showPlot = 0;
showPlot2 = 1;
showPlot3 = 0;
showPlot4 = 1;

Px = [5;8;10;10;12;20;18]*1.5;
Py = [10;2;7;5;15;5;17]*1.5;
Px=[7.5;12;15;21;18;30;27];
Py =[15;3;10.5;3.4;22.5;7.5;25.5];
Px2=Px;
Py2=Py;
xy=[Px Py];
xi = 2;
Px3=xy;
r2=0;
y_true = zeros(n,1);
xrange = max(crs(:,1));
yrange = max(crs(:,2));
[ XX, YY ] = meshgrid( x, y );
mu=[8 8];

sigma = 1;
  Z = ones(CRS/step,CRS/step);

Z=3*(exp((-1)*(0.0025)*((XX-65).^2 + (YY-70).^2)))+1*(exp((-1)*(0.009)*((XX-30).^2 + (YY-40).^2)));
[x1,y1]=meshgrid(step :step: CRS );
xyfine = [x1(:),y1(:)]; 
u=[Px2 Py2];
f=@(x) 3*(exp((-1)*(0.0025)*((x(1)-65).^2 + (x(2)-70).^2)))+1*(exp((-1)*(0.008)*((x(1)-30).^2 + (x(2)-40).^2)));

true1 =arrayfun(@(j) f(xyfine(j,:)),1:length(xyfine));


figure,pcolor(XX, YY, Z);
shading interp;
xlabel('x','FontSize',14);
ylabel('y','FontSize',14);
colorbar

axis([0,xrange,0,yrange]);
in_flag = 0;
dist = zeros(n+1,1);
last_errx = zeros(n+1,1);
last_erry = zeros(n+1,1);
Voltagex = zeros(n+1,1);
Voltagey = zeros(n+1,1);
max_speed = 1;
Umax = 1;
Umin = -0.5;
Kprop = 0.4; 

smax=1;
Ki = 0.015;
Kd = 0.2;
counter =0;
Px_plot=[];
Py_plot=[];
if showPlot2
    fig = figure(3);
    childs = allchild(fig);
    errorHandle = plot(counter,dist(1),'-','linewidth',1.5,'color',C{1});
    hold on
    error2Handle = plot(counter,dist(2),'-','linewidth',1.5,'color',C{2});
    hold on 
    error3Handle = plot(counter,dist(3),'-','linewidth',1.5,'color',C{3});
    hold on 
    error4Handle = plot(counter,dist(4),'-','linewidth',1.5,'color',C{4});
    hold on  
    error5Handle = plot(counter,dist(5),'-','linewidth',1.5,'color',C{5});
    hold on
    error6Handle = plot(counter,dist(6),'-','linewidth',1.5,'color',C{6});
    hold on 
    error7Handle = plot(counter,dist(7),'-','linewidth',1.5,'color',C{7});
    hold on 

    axis auto
    xlabel('Iterations');
    ylabel('Position Error');
    legend({'robot1','robot2','robot3','robot4','robot5','robot6','robot7','robot8','robot9','robot10'});  
end
    if showPlot3
    fig = figure(4);
    childs = allchild(fig);
    formationHandle = plot(counter,dist(1),'-','linewidth',2);
    hold on
    xlabel('Iterations');
    ylabel('Cost Function');
    end
 M1=zeros(1,n);
if showPlot4
    fig = figure(5);
    childs = allchild(fig);
     mHandle = plot(counter,M1(1),'-','linewidth',1.5,'color',C{1});
    hold on
    m2Handle = plot(counter,M1(2),'-','linewidth',1.5,'color',C{2});
    hold on 
    m3Handle = plot(counter,M1(3),'-','linewidth',1.5,'color',C{3});
    hold on 
    m4Handle = plot(counter,M1(4),'-','linewidth',1.5,'color',C{4});
    hold on  
    m5Handle = plot(counter,M1(5),'-','linewidth',1.5,'color',C{5});
    hold on
    m6Handle = plot(counter,M1(6),'-','linewidth',1.5,'color',C{6});
    hold on 
    m7Handle = plot(counter,M1(7),'-','linewidth',1.5,'color',C{7});
    hold on 

    axis auto
    xlabel('Iterations');
    ylabel('Area Of Voronoi');
    legend({'robot1','robot2','robot3','robot4','robot5','robot6','robot7','robot8','robot9','robot10'});  

end
 if showPlot4 
     plot(counter,r2,'-','linewidth',1.5,'color',C{1});
     fig = figure(6);
     childs = allchild(fig);
     r2Handle = plot(counter, r2,'-','linewidth',1.5,'color',C{1});
     hold on
     axis auto
     xlabel('Iterations');
     ylabel('r2');
     legend({'r2'});
 end
 averagedist=0;

  while counter<60
      counter = counter+1
            
            for i=1:n
                PX{i}=repmat( Px(i) , CRS/step , CRS/step );
                PY{i}=repmat( Py(i) , CRS/step , CRS/step );
                Dis{i}=sqrt([PX{i}-XX].*[PX{i}-XX]+[PY{i}-YY].*[PY{i}-YY]);%                                       
            end
             for i=1:n
                CAT(:,:,i)=Dis{i};
                 for j=1:n                    
                         CAT(:,:,j)=Dis{j};
                         Dis2Neb{counter}(i,j)=sqrt((Px(i) - Px(j))^2 + (Py(i)- Py(j))^2);
                 end
             [CC{i},II{i}]=min(CAT,[],3);
         end 
  %%         
    cfse = gpcf_sexp('magnSigma2',1,'lengthScale_prior',prior_t('s2',4),'magnSigma2_prior',prior_sqrtt('s2',10^2));
    lik = lik_gaussian('sigma2', 0.1, 'sigma2_prior', prior_fixed);

    gp = gp_set('cf', {cfse}, 'lik', lik ,'infer_params', 'covariance+likelihood');
     for t = 1:length(xy)
           y_true(t) =f(xy(t,:));
     end
       opt=optimset('TolFun',1e-3,'TolX',1e-4);
       gp = gp_optim(gp,xy,y_true,'opt',opt,'optimf',@fminlbfgs);
      [y_pred2,sd2] = gp_pred(gp, xy, y_true, [XX(:) YY(:)]);
     %%
      [rmse r2 ] = rsquare(y_pred2',true1);      

     Ans=zeros(CRS/step,CRS/step);      
       for i=1:n
           II{i}(~(II{i}==i))=0;
           
       end 
       
       for i=1:n
            Ans=Ans+II{i};
       end 
       Ans=Ans+1*Ans_ob;
       Ans(Ans<0)=-1;  
       for i=1:n
           [h{i}(:,1),h{i}(:,2)]=find(Ans==i);
           xyfine=[h{i}(:,1),h{i}(:,2)];
           [y_pred1,sd1] = gp_pred(gp, xy, y_true, xyfine);
           y_pred{i}(:,1)=y_pred1;
           sd{i}(:,1)=sd1;
           sigma(i)=0;

 
           if sigma(i)>1
               sigma(i)=1;
           end
           d = y_pred{i}(:,1) - y_true(i) - xi; 
           EI = (sd{i} ~= 0).*(d.*normcdf(d./sd{i}) + sd{i}.*normpdf(d./sd{i})); 
           [eimax,posEI] = max(EI);
           xEI(i,:) = xyfine(posEI,:);
       end
        H=zeros(2,n); 
        M1=zeros(1,n);
        M2=zeros(1,n);
        M3=zeros(1,n);
        S1=zeros(1,n);
        S2=zeros(1,n);
        S3=zeros(1,n);
        

        for j=1:n
            for i=1:size(h{j},1)              
                P=y_pred{j}(i,1);

               Sg= sd{j}(i,1)+log(sd{j}(i,1));

                if P<0
                    P=0;
                end
                H(1,j)=H(1,j)+x1(h{j}(i,1),h{j}(i,2));
                H(2,j)=H(2,j)+y1(h{j}(i,1),h{j}(i,2));       
                M1(1,j)=M1(1,j)+ P;
                M2(1,j)=M2(1,j)+x1(h{j}(i,1),h{j}(i,2))*P;
                M3(1,j)=M3(1,j)+y1(h{j}(i,1),h{j}(i,2))*P; 
                S1(1,j)=M1(1,j)+ Sg;
                S2(1,j)=M2(1,j)+x1(h{j}(i,1),h{j}(i,2))*Sg;
                S3(1,j)=M3(1,j)+y1(h{j}(i,1),h{j}(i,2))*Sg;            


            end
            if M1(1,j)==0
                    M1(1,j)=size(h{j},1);
                    M2(1,j)=H(1,j);
                    M3(1,j)=H(2,j);
            end
            
            if S1(1,j)==0
                    S1(1,j)=size(h{j},1);
                    S2(1,j)=H(1,j);
                    S3(1,j)=H(2,j);
            end

            M(counter,j)=size(h{j},1);
            H_av(1,j)=M2(1,j)/M1(1,j);
            H_av(2,j)=M3(1,j)/M1(1,j);
            
            S_av(1,j)=S2(1,j)/S1(1,j);
            S_av(2,j)=S3(1,j)/S1(1,j);
            SX(j,1)=S_av(1,j);
            SY(j,1)=S_av(2,j);


        end
            CX=H_av(1,:);
            CY=H_av(2,:);

 for i=1:n   
            %% 
         Px1(i,1)=Px(i);
         Py1(i,1)=Py(i);
         Voltagex(i) =  smax*(sigma(i)*(SX(i) - Px(i))+ Kprop*(CX(i) - Px(i)));
         Voltagey(i) =  smax*(sigma(i)*(SY(i) - Py(i))+ Kprop*(CY(i) - Py(i)));
                Px(i) = Px(i) + Voltagex(i) ; 
                Py(i) = Py(i) + Voltagey(i);
                last_errx(i) = CX(i) - Px(i);
                last_erry(i) = CY(i) - Py(i);
                
              Px4(i,1)=Px(i);
              Py4(i,1)=Py(i);
         dist1(i) = sqrt((Px1(i) - Px(i))^2 + (Py1(i) - Py(i))^2);
         if dist1(i)>6
                k=6;
                New_position=[Px1(i),Py1(i)]+k*[Px(i)-Px1(i), Py(i)-Py1(i)]/dist1(i);
                Px(i)=New_position(1,1);
                Py(i)=New_position(1,2);
        end
                
                Px2(i,1)=Px(i);
                Py2(i,1)=Py(i);
                 Px2(end+1,:) =Px2(i);
                 Py2(end+1,:) =Py2(i);
                dist(i) = sqrt((CX(i) - Px(i))^2 + (CY(i) - Py(i))^2);
                xy(end+1,:) = [Px(i) Py(i)];
         end
        if counter ==1
           figure 
           contourf(Ans);

           title(['o = Robots, + = Goals, Iteration ', num2str(counter-1)]);
           hold on          
           plot(Px1,Py1,'k.','Linewidth',1.5,'MarkerSize',10);hold on
           for i=1:n                
                    fill(xc(i,:)+Px1(i), yc(i,:)+Py1(i),'k')                    
                    hold on
                    plot(Px1(i)+xcl(i,:),Py1(i)+ycl(i,:),'r-','Linewidth',1,'MarkerSize',10);
                    hold on
           end

           hold on 
           Px_plot=[Px_plot,Px1];
           Py_plot=[Py_plot,Py1];
           axis([0,100,0,100]);
           axis square;
        end   

        
         averagedist = 0;

                  figure

                contourf(Ans);

                title(['o = Robots, + = Goals, Iteration ', num2str(counter)]);
                hold on 

                plot(Px1,Py1,'k.','Linewidth',1.5,'MarkerSize',15);hold on
                 for i=1:n                
                    plot(Px1(i)+xc(i,:),Py1(i)+yc(i,:),'k-','Linewidth',1,'MarkerSize',10);
                    fill(xc(i,:)+Px1(i), yc(i,:)+Py1(i),'k')                    
                    hold on
                    plot(Px1(i)+xcl(i,:),Py1(i)+ycl(i,:),'r-','Linewidth',1,'MarkerSize',10);
                    hold on
                 end

                hold on
                 axis([0,100,0,100]);
                 axis square;
                Px_plot=[Px_plot,Px1];
                Py_plot=[Py_plot,Py1];
      for i=1:n
         for j=1:n
             if i~=j
                Dis2Neb{counter}(i,j)=0.1*(sqrt((Px(i) - Px(j))^2 + (Py(i)- Py(j))^2));
             end
         end 
      end
                if counter>=1&&guiji
                  for j=1:size(Px_plot,2)-1
                     for i=1:n                    
                       plot([Px_plot(i,j) Px_plot(i,j+1)],[Py_plot(i,j) Py_plot(i,j+1)],'color',C{i},'linewidth',1.5);
                       hold on 
                     end
                  end
                end

           if showPlot2
            xD2=[get(errorHandle,'XData'),counter];
            yD2=[get(errorHandle,'YData'),dist(1)];
            xD3=[get(error2Handle,'XData'),counter];
            yD3=[get(error2Handle,'YData'),dist(2)];
            xD4=[get(error3Handle,'XData'),counter];
            yD4=[get(error3Handle,'YData'),dist(3)];
            xD5=[get(error4Handle,'XData'),counter];
            yD5=[get(error4Handle,'YData'),dist(4)];
             xD6=[get(error5Handle,'XData'),counter];
            yD6=[get(error5Handle,'YData'),dist(5)];
            xD7=[get(error6Handle,'XData'),counter];
            yD7=[get(error6Handle,'YData'),dist(6)];
            xD8=[get(error7Handle,'XData'),counter];
            yD8=[get(error7Handle,'YData'),dist(7)];

            set(errorHandle,'XData',xD2,'YData',yD2);
            set(error2Handle,'XData',xD3,'YData',yD3);
            set(error3Handle,'XData',xD4,'YData',yD4);
            set(error4Handle,'XData',xD5,'YData',yD5);
            set(error5Handle,'XData',xD6,'YData',yD6);
            set(error6Handle,'XData',xD7,'YData',yD7);
            set(error7Handle,'XData',xD8,'YData',yD8);

           end
        if showPlot3
             fx=[get(formationHandle,'XData'),counter];
             if (counter <= 89)
                fy=[get(formationHandle,'YData'),averagedist];
             else
                 fy=[get(formationHandle,'YData'),averagedist];
             end
            set(formationHandle,'XData',fx,'YData',fy);
        end
            hold on
            drawnow 
              if showPlot2
            xD2=[get(mHandle,'XData'),counter];
            yD2=[get(mHandle,'YData'),M(counter,1)/1000000];
            xD3=[get(m2Handle,'XData'),counter];
            yD3=[get(m2Handle,'YData'),M(counter,2)/1000000];
            xD4=[get(m3Handle,'XData'),counter];
            yD4=[get(m3Handle,'YData'),M(counter,3)/1000000];
            xD5=[get(m4Handle,'XData'),counter];
            yD5=[get(m4Handle,'YData'),M(counter,4)/1000000];
            xD6=[get(m5Handle,'XData'),counter];
            yD6=[get(m5Handle,'YData'),M(counter,5)/1000000];
            xD7=[get(m6Handle,'XData'),counter];
            yD7=[get(m6Handle,'YData'),M(counter,6)/1000000];
            xD8=[get(m7Handle,'XData'),counter];
            yD8=[get(m7Handle,'YData'),M(counter,7)/1000000];

            
            r2xD=[get(r2Handle,'XData'),counter];
            r2yD=[get(r2Handle,'YData'),r2];
           set(r2Handle,'XData',r2xD,'YData',r2yD);
            
            set(mHandle,'XData',xD2,'YData',yD2);
            set(m2Handle,'XData',xD3,'YData',yD3);
            set(m3Handle,'XData',xD4,'YData',yD4);
            set(m4Handle,'XData',xD5,'YData',yD5);
            set(m5Handle,'XData',xD6,'YData',yD6);
            set(m6Handle,'XData',xD7,'YData',yD7);
            set(m7Handle,'XData',xD8,'YData',yD8);


           end
clear h;
clear Ans1; clear h;clear y_pred;clear sd;
  end
%% 
for i=2:counter
    Dis2Neb{i-1}=Dis2Neb{i};
end
for i=1:counter
    Dis2Neb{1,i}(Dis2Neb{1,i}==0)=100;
    Dis2Neb{2,i}=min(Dis2Neb{1,i}');
end
figure
for i=1:counter-1
    for j=1:n
    plot([i i+1],[Dis2Neb{2,i}(j) Dis2Neb{2,i+1}(j)],'color',C{j},'linewidth',1.5);
    hold on
    end
end
hold on
plot([0,60],[0.5,0.5],'LineStyle','--','color',[1 0 0],'linewidth',1.5)
 xlabel('Iterations');
 ylabel('Distance to Nearest Robot');
legend({'p1','p2','p3','p4','p5','p6','p7'}); 
axis([0 60 0 5])

zzz=reshape(y_pred2,100,100)

figure,pcolor(XX, YY, zzz);
shading interp;
xlabel('x','FontSize',14);
ylabel('y','FontSize',14);
set(gca, 'XTick', [10,20,30,40,50,60,70,80,90,99]);
set(gca,'XTickLabel',{'1','2','3','4','5','6','7','8','9','10'})
set(gca, 'YTick', [10,20,30,40,50,60,70,80,90,99] );
set(gca,'YTickLabel',{'1','2','3','4','5','6','7','8','9','10'})
colorbar
caxis([0 3])

